//
//  RepositoryTableViewCell.swift
//  bloodAssitant
//
//  Created by Nilaykumar Jha on 2018-11-13.
//  Copyright © 2018 Abhishekkumar Israni. All rights reserved.
//

import UIKit

class RepositoryTableViewCell: UITableViewCell {
    
}
