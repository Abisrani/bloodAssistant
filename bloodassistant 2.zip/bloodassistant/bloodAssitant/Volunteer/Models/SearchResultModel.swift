//
//  SearchResultModel.swift
//  bloodAssitant
//
//  Created by Nilaykumar Jha on 2018-12-06.
//  Copyright © 2018 Abhishekkumar Israni. All rights reserved.
//

import Foundation

class SearchResultModel {
    var to_user_id: Int?
    var name: String?
    var units: Int?
    var addres: String?
    var lat: Double?
    var lng: Double?
    var email: String?
    var phone: String?
}
