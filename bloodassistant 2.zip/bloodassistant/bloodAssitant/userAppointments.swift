//
//  userAppointments.swift
//  bloodAssitant
//
//  Created by Abhishekkumar Israni on 2018-11-29.
//  Copyright © 2018 Abhishekkumar Israni. All rights reserved.
//

import UIKit

class userAppointments: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
